package com.example.ch15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
